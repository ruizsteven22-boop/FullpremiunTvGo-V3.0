const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const PORT = process.env.PORT || 3000;

http.createServer(async (req, res) => {
  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost:' + PORT}`);
  let pathname = parsedUrl.pathname;

  // Endpoint Proxy de Streaming
  if (pathname === '/proxy') {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, OPTIONS');
    
    const targetUrl = parsedUrl.searchParams.get('url');
    if (!targetUrl) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      return res.end('Falta la URL de destino');
    }

    try {
      const upstreamUrl = new URL(targetUrl);
      const lib = upstreamUrl.protocol === 'https:' ? https : http;

      const options = {
        hostname: upstreamUrl.hostname,
        port: upstreamUrl.port || (upstreamUrl.protocol === 'https:' ? 443 : 80),
        path: upstreamUrl.pathname + upstreamUrl.search,
        method: 'GET',
        headers: {
          'User-Agent': 'VLC/3.0.20 LibVLC/3.0.20',
          'Accept': '*/*',
          'Connection': 'keep-alive'
        }
      };

      const proxyReq = lib.request(options, (proxyRes) => {
        if ([301, 302, 303, 307, 308].includes(proxyRes.statusCode)) {
          const redirectUrl = proxyRes.headers['location'];
          if (redirectUrl) {
            res.writeHead(302, { 'Location': `/proxy?url=${encodeURIComponent(redirectUrl)}` });
            res.end();
            return;
          }
        }

        res.writeHead(200, {
          'Content-Type': proxyRes.headers['content-type'] || 'video/mp2t',
          'Access-Control-Allow-Origin': '*'
        });
        proxyRes.pipe(res);
      });

      proxyReq.on('error', () => {
        if (!res.headersSent) res.writeHead(502).end('Error de enlace con el servidor de streaming');
      });

      req.on('close', () => proxyReq.destroy());
      proxyReq.end();
    } catch (err) {
      if (!res.headersSent) res.writeHead(500).end('Error interno en proxy: ' + err.message);
    }
    return;
  }

  // Servir archivos estáticos
  if (pathname === '/' || pathname === '/app') pathname = '/index.html';
  
  const filePath = path.join(__dirname, 'public', pathname);
  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
      res.end('Página no encontrada');
      return;
    }
    const ext = path.extname(filePath);
    const mimeTypes = { '.html': 'text/html', '.js': 'text/javascript', '.css': 'text/css' };
    res.writeHead(200, { 'Content-Type': mimeTypes[ext] || 'text/plain' });
    res.end(data);
  });

}).listen(PORT, () => {
  console.log(`>>> FULL PREMIUM TVGO ACTIVO EN PUERTO ${PORT} <<<`);
});